var searchData=
[
  ['setx_14',['setX',['../class_my_exp.html#a3faa1a42c2749758a7b2faf32e8b6c4b',1,'MyExp']]]
];
