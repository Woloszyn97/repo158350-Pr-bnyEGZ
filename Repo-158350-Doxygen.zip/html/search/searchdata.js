var indexSectionsWithContent =
{
  0: "gmsv~",
  1: "m",
  2: "m",
  3: "gmsv~"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "Wszystko",
  1: "Klasy",
  2: "Pliki",
  3: "Funkcje"
};

